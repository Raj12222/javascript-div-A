function demoonclick(){
    alert("on click");
}

function demoonclick(){
    alert("on double click");
}

function demofocus(){
    document.getElementById("textfocus").style.backgroundColor="yellow";
}

function demoonblur(){
    document.getElementById("textblur").style.backgroundColor="blue";
}

function demoonkeypress(){
    alert("keypress done");
}

function demokeyup(){
    alert("keyup done");
}