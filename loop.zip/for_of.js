const cities =["new york",  "tokiyo",  "delhi"];
for(C of cities ) {
    document.write("<be/>"+C);
}
