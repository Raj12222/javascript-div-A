var n1=10,n2="10";

// == equai to value only.
if(n1==n2){
    document.write("<br/>same.");
}
else
{
    document.write("<br/>not same.");
}

// ===equal to bvalue & type.
if(n1===n2){
    document.write("<br/>same.");
}
else
{
    document.write("<br/>not same.");
}

var n11=10,n22=10;

// == equal to value only
if(n11==n22){
    document.write("<br/>same.");
}
else
{
    document.write("<br/>not same.");
}

// ===equal to value & type.
if(n11===n22){
    document.write("<br/>same.");
}
else
{
    document.write("<br/>not same.");
}

// similar for not equal to nad not equal to value and type.