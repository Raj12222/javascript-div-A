lat n1=20,n2=30;

var sum=n1+n2;
var mul=n1*n2;
var sub=n1-n2;
var div=n1/n2;
var mod=n1%n2;
var exponentiation=5**2; //sam as pow.
document.write("<br/>sum:",sum+"<br/>mul:",mul+"<br/>sub:",sub+"<br/>div:",div+"<br/>dec:",n1--+"<br/>pre inc:",++n1+"<br/>pre dec:",--n1+"<br/>exp:",exponentiation);