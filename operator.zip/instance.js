// typeof
// array instance of
var a = ["silver", "oak"];
document.write(a instanceof array);

document.write("<br/>");

// class  instance of
class ractangle {
    constructor(height, width){
        this.height = height;
        this.width = width;
    }
}
var R=new ractangle(10,20);
document.write(R instanceof ractangle);

document.write("<br/>");


document.write(R.height+R.width);