function externalalert(){
    alert("Hello Guys I'm Raj.");
}


function externalconfirm(){
    if(confirm("Are You Sure????"))
    {
        alert("Yesssss");

    }
    else
    {
        alert("Noooooo");
    }
}

function externalpromt(){

    var fname=prompt("Enter Your First Name Here");
    var lname=prompt("Enter Your Last Name Here");
    alert(fname +" "+ lname);

}